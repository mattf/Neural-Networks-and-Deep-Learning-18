from mnist import mnist_loader

training_data, validation_data, test_data = mnist_loader.load_data_wrapper()
training_data = list(training_data)

training_data[0][0].shape,training_data[0][0]

training_data[0][1].shape,training_data[0][1]

import matplotlib.pyplot as plt
img = training_data[0][0].reshape(28, 28)  # 把一维数据还原为三维
plt.imshow(img)
plt.show()

plt.imshow(img,cmap='gray')
plt.show()

import numpy as np
np.argmax(training_data[0][1])

plt.title(np.argmax(training_data[0][1]))
plt.imshow(img,cmap='gray')
plt.show()

def plot_one(i):
    img = training_data[i][0].reshape(28, 28)
    plt.title(np.argmax(training_data[i][1]))
    plt.imshow(img,cmap='gray')
    plt.show()
plot_one(5)
plot_one(100)

from mnist import network2
net_2 = network2.Network([784, 30, 10], cost=network2.CrossEntropyCost)
net_2.large_weight_initializer()
net_2.SGD(training_data, 30, 10, 0.1, lmbda = 5.0,evaluation_data=validation_data,
    monitor_evaluation_accuracy=True)

